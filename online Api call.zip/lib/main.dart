import 'package:flutter/material.dart';
import 'api_use_page.dart';
import 'view_data_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        title: Row(
          children: [
            Image.asset('assets/logo.png', height: 40),
            SizedBox(width: 10),
            Text('Baba Guru Nanak University'),
            Spacer(),
            IconButton(icon: Icon(Icons.school), onPressed: () {}),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.lightBlue),
              child: Text(
                'BGNU Navigation',
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
            ListTile(
              leading: Icon(Icons.cloud_download),
              title: Text('API Use'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>  OnlineApiPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.table_view),
              title: Text('View Data'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ViewDataPage()),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                      'BABA GURU NANAK UNIVERSITY',
                      style: TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 30),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.asset(
                        'assets/pic.jpg',
                        height: 200,
                        width: 600,
                        fit: BoxFit.cover,
                      ),
                    ),
                    SizedBox(height: 10),
                    Card(
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "About Baba Guru Nanak University",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Colors.lightBlue,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Baba Guru Nanak University (BGNU) is a prestigious public-sector university located in Nankana Sahib, Punjab, Pakistan. "
                                  "The university is designed to accommodate 10,000 to 15,000 students worldwide and aims to provide quality education in multiple disciplines.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "BGNU offers a wide range of programs, including Medicine, Pharmacy, Engineering, Computer Science, Languages, and Social Sciences. "
                                  "An initial budget of PKR 6 billion has been allocated for development in three phases.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "The university has signed MOUs with Govt. Guru Nanak (Post Graduate) College and Govt. Guru Nanak Associate College for Women "
                                  "for technical assistance and temporary classrooms until the academic buildings are completed.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "The foundation stone was laid on October 28, 2019, by the Prime Minister of Pakistan. The Punjab Government passed the BGNU Act in 2020, "
                                  "ensuring the university meets global educational standards.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: 10),
                            Text(
                              "For Fall 2024, admissions will open soon with a range of academic programs. The university has also established a Centre of Excellence "
                                  "for Baba Guru Nanak & Sikh Cultural Heritage and a dedicated Chair for Punjab Studies.",
                              style: TextStyle(fontSize: 16, color: Colors.black87),
                              textAlign: TextAlign.justify,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            color: Colors.lightBlue,
            child: Center(
              child: Text(
                '© 2025 Baba Guru Nanak University | All Rights Reserved',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
