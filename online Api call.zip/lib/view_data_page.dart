// view_data_page.dart
import 'package:flutter/material.dart';

class ViewDataPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("View Data")),
      body: Center(child: Text("This is the View Data Page")),
    );
  }
}
